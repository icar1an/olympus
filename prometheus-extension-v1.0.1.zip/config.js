/**
 * Prometheus Configuration
 * 
 * Firebase Web App: Prometheus Extension
 * Registered: 2026-01-05
 */

export const CONFIG = {
    // Firebase Configuration (prometheus-ext-2026 project)
    firebase: {
        apiKey: 'AIzaSyAZRw6SHBgz8vKARoeH_nsWkzqR6c4Acdw',
        authDomain: 'prometheus-ext-2026.firebaseapp.com',
        projectId: 'prometheus-ext-2026',
        storageBucket: 'prometheus-ext-2026.firebasestorage.app',
        messagingSenderId: '707111034542',
        appId: '1:707111034542:web:198881162ad3a706f0173f'
    },

    // Pinterest API Configuration
    pinterest: {
        clientId: '1531950',
        // Client secret stored in Firebase Secret Manager (never expose in frontend)
        scope: 'boards:read,pins:read,user_accounts:read'
    },

    // Firebase Cloud Functions URLs (Gen 1 functions)
    functions: {
        baseUrl: 'https://us-central1-prometheus-ext-2026.cloudfunctions.net',
        // Gen 1 Function URLs
        analyzeImageUrl: 'https://us-central1-prometheus-ext-2026.cloudfunctions.net/analyzeImage',
        healthCheckUrl: 'https://us-central1-prometheus-ext-2026.cloudfunctions.net/healthCheck',
        // Pinterest Functions
        exchangePinterestTokenUrl: 'https://us-central1-prometheus-ext-2026.cloudfunctions.net/exchangePinterestToken',
        getPinterestBoardsUrl: 'https://us-central1-prometheus-ext-2026.cloudfunctions.net/getPinterestBoards',
        getPinterestBoardPinsUrl: 'https://us-central1-prometheus-ext-2026.cloudfunctions.net/getPinterestBoardPins',
        // Legacy endpoints (for future use)
        endpoints: {
            analyze: '/analyze',
            generateCard: '/generateCard',
            getRunwayReferences: '/getRunwayReferences'
        }
    },

    // Gemini AI Configuration
    gemini: {
        model: 'gemini-2.5-flash',
        apiEndpoint: 'https://generativelanguage.googleapis.com/v1beta',
        maxOutputTokens: 2048,
        temperature: 0.3
    },

    // Feature Flags
    features: {
        pinterestIntegration: true,
        shareableCards: true,
        runwayReferences: true,
        collections: true,
        geminiAnalysis: true
    },

    // Analytics
    analytics: {
        enabled: false,
        measurementId: null
    }
};

export default CONFIG;
